/* =========================================================================
    Unity - A Test Framework for C
    ThrowTheSwitch.org
    Copyright (c) 2007-26 Mike Karlesky, Mark VanderVoord, & Greg Williams
    SPDX-License-Identifier: MIT
========================================================================= */

#define UNITY_DETAIL_STACK_SIZE  5
#define LABEL_AS_INT32 "#\x18"  /*UNITY_DISPLAY_STYLE_INT32 = 0x18 */
#define LABEL_AS_HEX8 "#\x41"   /* UNITY_DISPLAY_STYLE_HEX8 = 0x41 */
#define UNITY_DETAIL_LABEL_NAMES { 0, \
    UNITY_DETAIL1_NAME, \
    UNITY_DETAIL2_NAME, \
    "During call", \
    LABEL_AS_INT32 "Bit Position", \
    LABEL_AS_HEX8 "Bit Mask", \
}
typedef enum {
    UNITY_DETAIL_NONE = 0,
    UNITY_DETAIL_D1 = 1,
    UNITY_DETAIL_D2 = 2,
    UNITY_DETAIL_CALL,
    UNITY_DETAIL_BIT_POS,
    UNITY_DETAIL_BIT_MASK,
} UNITY_DETAIL_LABEL_T;
